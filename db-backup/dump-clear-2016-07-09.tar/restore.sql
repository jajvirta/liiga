--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

DROP DATABASE tfsliiga;
--
-- Name: tfsliiga; Type: DATABASE; Schema: -; Owner: tfsliiga
--

CREATE DATABASE tfsliiga WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'fi_FI.UTF-8' LC_CTYPE = 'fi_FI.UTF-8';


ALTER DATABASE tfsliiga OWNER TO tfsliiga;

\connect tfsliiga

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: henkilo; Type: TABLE; Schema: public; Owner: tfsliiga; Tablespace: 
--

CREATE TABLE henkilo (
    henkilo_id integer NOT NULL,
    henkilo_nimi text,
    sahkoposti text,
    puhelinnumero text,
    oauth_tunnus text,
    yhteyshenkilo_k_e character(1),
    vahvistettu_k_e character(1),
    CONSTRAINT y_k_e CHECK ((yhteyshenkilo_k_e = ANY (ARRAY['K'::bpchar, 'E'::bpchar])))
);


ALTER TABLE public.henkilo OWNER TO tfsliiga;

--
-- Name: henkilo_henkilo_id_seq; Type: SEQUENCE; Schema: public; Owner: tfsliiga
--

CREATE SEQUENCE henkilo_henkilo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.henkilo_henkilo_id_seq OWNER TO tfsliiga;

--
-- Name: henkilo_henkilo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tfsliiga
--

ALTER SEQUENCE henkilo_henkilo_id_seq OWNED BY henkilo.henkilo_id;


--
-- Name: jokumuu; Type: TABLE; Schema: public; Owner: tfsliiga; Tablespace: 
--

CREATE TABLE jokumuu (
    id bigint,
    joku text,
    muu text
);


ALTER TABLE public.jokumuu OWNER TO tfsliiga;

--
-- Name: joukkue; Type: TABLE; Schema: public; Owner: tfsliiga; Tablespace: 
--

CREATE TABLE joukkue (
    joukkue_id integer NOT NULL,
    nimi text,
    kotirata text,
    luotu timestamp without time zone DEFAULT now(),
    ilmo_vahvistettu_k_e character(1),
    yhteyshenkilo_id integer,
    joukkue_kuvaus text,
    CONSTRAINT ilmovahv_k_e CHECK ((ilmo_vahvistettu_k_e = ANY (ARRAY['K'::bpchar, 'E'::bpchar])))
);


ALTER TABLE public.joukkue OWNER TO tfsliiga;

--
-- Name: joukkue_joukkue_id_seq; Type: SEQUENCE; Schema: public; Owner: tfsliiga
--

CREATE SEQUENCE joukkue_joukkue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.joukkue_joukkue_id_seq OWNER TO tfsliiga;

--
-- Name: joukkue_joukkue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tfsliiga
--

ALTER SEQUENCE joukkue_joukkue_id_seq OWNED BY joukkue.joukkue_id;


--
-- Name: lohko; Type: TABLE; Schema: public; Owner: tfsliiga; Tablespace: 
--

CREATE TABLE lohko (
    lohko_id integer NOT NULL,
    lohko_nimi text,
    lohkon_sarja_id integer
);


ALTER TABLE public.lohko OWNER TO tfsliiga;

--
-- Name: lohko_joukkue; Type: TABLE; Schema: public; Owner: tfsliiga; Tablespace: 
--

CREATE TABLE lohko_joukkue (
    lohkojoukkue_lohko_id integer NOT NULL,
    lohkojoukkue_joukkue_id integer NOT NULL
);


ALTER TABLE public.lohko_joukkue OWNER TO tfsliiga;

--
-- Name: lohko_lohko_id_seq; Type: SEQUENCE; Schema: public; Owner: tfsliiga
--

CREATE SEQUENCE lohko_lohko_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lohko_lohko_id_seq OWNER TO tfsliiga;

--
-- Name: lohko_lohko_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tfsliiga
--

ALTER SEQUENCE lohko_lohko_id_seq OWNED BY lohko.lohko_id;


--
-- Name: ottelu; Type: TABLE; Schema: public; Owner: tfsliiga; Tablespace: 
--

CREATE TABLE ottelu (
    ottelu_id integer NOT NULL,
    ottelun_sarja_id integer,
    pelipaiva date,
    kotijoukkue_id integer,
    vierasjoukkue_id integer,
    kotijoukkue_pisteet integer,
    vierasjoukkue_pisteet integer
);


ALTER TABLE public.ottelu OWNER TO tfsliiga;

--
-- Name: ottelu_ottelu_id_seq; Type: SEQUENCE; Schema: public; Owner: tfsliiga
--

CREATE SEQUENCE ottelu_ottelu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ottelu_ottelu_id_seq OWNER TO tfsliiga;

--
-- Name: ottelu_ottelu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tfsliiga
--

ALTER SEQUENCE ottelu_ottelu_id_seq OWNED BY ottelu.ottelu_id;


--
-- Name: reikapeli; Type: TABLE; Schema: public; Owner: tfsliiga; Tablespace: 
--

CREATE TABLE reikapeli (
    peli_id integer NOT NULL,
    peli_ottelu_id integer,
    pelaaja_koti integer,
    koti_tulos integer,
    koti_pisteet integer,
    pelaaja_vieras integer,
    vieras_tulos integer,
    vieras_pisteet integer
);


ALTER TABLE public.reikapeli OWNER TO tfsliiga;

--
-- Name: reikapeli_peli_id_seq; Type: SEQUENCE; Schema: public; Owner: tfsliiga
--

CREATE SEQUENCE reikapeli_peli_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reikapeli_peli_id_seq OWNER TO tfsliiga;

--
-- Name: reikapeli_peli_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tfsliiga
--

ALTER SEQUENCE reikapeli_peli_id_seq OWNED BY reikapeli.peli_id;


--
-- Name: sarja; Type: TABLE; Schema: public; Owner: tfsliiga; Tablespace: 
--

CREATE TABLE sarja (
    sarja_id integer NOT NULL,
    sarja_nimi text,
    ajankohta_teksti text,
    aktiivinen_k_e character(1),
    testisarja_k_e character(1),
    CONSTRAINT akt_k_e CHECK ((aktiivinen_k_e = ANY (ARRAY['K'::bpchar, 'E'::bpchar]))),
    CONSTRAINT testisarja_k_e CHECK ((testisarja_k_e = ANY (ARRAY['K'::bpchar, 'E'::bpchar])))
);


ALTER TABLE public.sarja OWNER TO tfsliiga;

--
-- Name: sarja_joukkue; Type: TABLE; Schema: public; Owner: tfsliiga; Tablespace: 
--

CREATE TABLE sarja_joukkue (
    sarjajoukkue_sarja_id integer,
    sarjajoukkue_joukkue_id integer
);


ALTER TABLE public.sarja_joukkue OWNER TO tfsliiga;

--
-- Name: sarja_sarja_id_seq; Type: SEQUENCE; Schema: public; Owner: tfsliiga
--

CREATE SEQUENCE sarja_sarja_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sarja_sarja_id_seq OWNER TO tfsliiga;

--
-- Name: sarja_sarja_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tfsliiga
--

ALTER SEQUENCE sarja_sarja_id_seq OWNED BY sarja.sarja_id;


--
-- Name: schema_version; Type: TABLE; Schema: public; Owner: tfsliiga; Tablespace: 
--

CREATE TABLE schema_version (
    version_rank integer NOT NULL,
    installed_rank integer NOT NULL,
    version character varying(50) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.schema_version OWNER TO tfsliiga;

--
-- Name: yhteyshenkilo_joukkue; Type: VIEW; Schema: public; Owner: tfsliiga
--

CREATE VIEW yhteyshenkilo_joukkue AS
 SELECT joukkue.joukkue_id,
    joukkue.nimi,
    joukkue.kotirata,
    joukkue.luotu,
    joukkue.ilmo_vahvistettu_k_e,
    joukkue.yhteyshenkilo_id,
    joukkue.joukkue_kuvaus,
    henkilo.henkilo_id,
    henkilo.henkilo_nimi,
    henkilo.sahkoposti,
    henkilo.puhelinnumero,
    henkilo.oauth_tunnus,
    henkilo.yhteyshenkilo_k_e,
    henkilo.vahvistettu_k_e
   FROM (joukkue
     JOIN henkilo ON ((joukkue.yhteyshenkilo_id = henkilo.henkilo_id)));


ALTER TABLE public.yhteyshenkilo_joukkue OWNER TO tfsliiga;

--
-- Name: henkilo_id; Type: DEFAULT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY henkilo ALTER COLUMN henkilo_id SET DEFAULT nextval('henkilo_henkilo_id_seq'::regclass);


--
-- Name: joukkue_id; Type: DEFAULT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY joukkue ALTER COLUMN joukkue_id SET DEFAULT nextval('joukkue_joukkue_id_seq'::regclass);


--
-- Name: lohko_id; Type: DEFAULT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY lohko ALTER COLUMN lohko_id SET DEFAULT nextval('lohko_lohko_id_seq'::regclass);


--
-- Name: ottelu_id; Type: DEFAULT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY ottelu ALTER COLUMN ottelu_id SET DEFAULT nextval('ottelu_ottelu_id_seq'::regclass);


--
-- Name: peli_id; Type: DEFAULT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY reikapeli ALTER COLUMN peli_id SET DEFAULT nextval('reikapeli_peli_id_seq'::regclass);


--
-- Name: sarja_id; Type: DEFAULT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY sarja ALTER COLUMN sarja_id SET DEFAULT nextval('sarja_sarja_id_seq'::regclass);


--
-- Data for Name: henkilo; Type: TABLE DATA; Schema: public; Owner: tfsliiga
--

COPY henkilo (henkilo_id, henkilo_nimi, sahkoposti, puhelinnumero, oauth_tunnus, yhteyshenkilo_k_e, vahvistettu_k_e) FROM stdin;
\.
COPY henkilo (henkilo_id, henkilo_nimi, sahkoposti, puhelinnumero, oauth_tunnus, yhteyshenkilo_k_e, vahvistettu_k_e) FROM '$$PATH$$/2073.dat';

--
-- Name: henkilo_henkilo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tfsliiga
--

SELECT pg_catalog.setval('henkilo_henkilo_id_seq', 25, true);


--
-- Data for Name: jokumuu; Type: TABLE DATA; Schema: public; Owner: tfsliiga
--

COPY jokumuu (id, joku, muu) FROM stdin;
\.
COPY jokumuu (id, joku, muu) FROM '$$PATH$$/2071.dat';

--
-- Data for Name: joukkue; Type: TABLE DATA; Schema: public; Owner: tfsliiga
--

COPY joukkue (joukkue_id, nimi, kotirata, luotu, ilmo_vahvistettu_k_e, yhteyshenkilo_id, joukkue_kuvaus) FROM stdin;
\.
COPY joukkue (joukkue_id, nimi, kotirata, luotu, ilmo_vahvistettu_k_e, yhteyshenkilo_id, joukkue_kuvaus) FROM '$$PATH$$/2077.dat';

--
-- Name: joukkue_joukkue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tfsliiga
--

SELECT pg_catalog.setval('joukkue_joukkue_id_seq', 25, true);


--
-- Data for Name: lohko; Type: TABLE DATA; Schema: public; Owner: tfsliiga
--

COPY lohko (lohko_id, lohko_nimi, lohkon_sarja_id) FROM stdin;
\.
COPY lohko (lohko_id, lohko_nimi, lohkon_sarja_id) FROM '$$PATH$$/2083.dat';

--
-- Data for Name: lohko_joukkue; Type: TABLE DATA; Schema: public; Owner: tfsliiga
--

COPY lohko_joukkue (lohkojoukkue_lohko_id, lohkojoukkue_joukkue_id) FROM stdin;
\.
COPY lohko_joukkue (lohkojoukkue_lohko_id, lohkojoukkue_joukkue_id) FROM '$$PATH$$/2084.dat';

--
-- Name: lohko_lohko_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tfsliiga
--

SELECT pg_catalog.setval('lohko_lohko_id_seq', 2, true);


--
-- Data for Name: ottelu; Type: TABLE DATA; Schema: public; Owner: tfsliiga
--

COPY ottelu (ottelu_id, ottelun_sarja_id, pelipaiva, kotijoukkue_id, vierasjoukkue_id, kotijoukkue_pisteet, vierasjoukkue_pisteet) FROM stdin;
\.
COPY ottelu (ottelu_id, ottelun_sarja_id, pelipaiva, kotijoukkue_id, vierasjoukkue_id, kotijoukkue_pisteet, vierasjoukkue_pisteet) FROM '$$PATH$$/2079.dat';

--
-- Name: ottelu_ottelu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tfsliiga
--

SELECT pg_catalog.setval('ottelu_ottelu_id_seq', 72, true);


--
-- Data for Name: reikapeli; Type: TABLE DATA; Schema: public; Owner: tfsliiga
--

COPY reikapeli (peli_id, peli_ottelu_id, pelaaja_koti, koti_tulos, koti_pisteet, pelaaja_vieras, vieras_tulos, vieras_pisteet) FROM stdin;
\.
COPY reikapeli (peli_id, peli_ottelu_id, pelaaja_koti, koti_tulos, koti_pisteet, pelaaja_vieras, vieras_tulos, vieras_pisteet) FROM '$$PATH$$/2081.dat';

--
-- Name: reikapeli_peli_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tfsliiga
--

SELECT pg_catalog.setval('reikapeli_peli_id_seq', 1, false);


--
-- Data for Name: sarja; Type: TABLE DATA; Schema: public; Owner: tfsliiga
--

COPY sarja (sarja_id, sarja_nimi, ajankohta_teksti, aktiivinen_k_e, testisarja_k_e) FROM stdin;
\.
COPY sarja (sarja_id, sarja_nimi, ajankohta_teksti, aktiivinen_k_e, testisarja_k_e) FROM '$$PATH$$/2075.dat';

--
-- Data for Name: sarja_joukkue; Type: TABLE DATA; Schema: public; Owner: tfsliiga
--

COPY sarja_joukkue (sarjajoukkue_sarja_id, sarjajoukkue_joukkue_id) FROM stdin;
\.
COPY sarja_joukkue (sarjajoukkue_sarja_id, sarjajoukkue_joukkue_id) FROM '$$PATH$$/2085.dat';

--
-- Name: sarja_sarja_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tfsliiga
--

SELECT pg_catalog.setval('sarja_sarja_id_seq', 2, true);


--
-- Data for Name: schema_version; Type: TABLE DATA; Schema: public; Owner: tfsliiga
--

COPY schema_version (version_rank, installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
\.
COPY schema_version (version_rank, installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM '$$PATH$$/2070.dat';

--
-- Name: henkilo_pkey; Type: CONSTRAINT; Schema: public; Owner: tfsliiga; Tablespace: 
--

ALTER TABLE ONLY henkilo
    ADD CONSTRAINT henkilo_pkey PRIMARY KEY (henkilo_id);


--
-- Name: joukkue_pkey; Type: CONSTRAINT; Schema: public; Owner: tfsliiga; Tablespace: 
--

ALTER TABLE ONLY joukkue
    ADD CONSTRAINT joukkue_pkey PRIMARY KEY (joukkue_id);


--
-- Name: lohko_joukkue_pkey; Type: CONSTRAINT; Schema: public; Owner: tfsliiga; Tablespace: 
--

ALTER TABLE ONLY lohko_joukkue
    ADD CONSTRAINT lohko_joukkue_pkey PRIMARY KEY (lohkojoukkue_lohko_id, lohkojoukkue_joukkue_id);


--
-- Name: lohko_pkey; Type: CONSTRAINT; Schema: public; Owner: tfsliiga; Tablespace: 
--

ALTER TABLE ONLY lohko
    ADD CONSTRAINT lohko_pkey PRIMARY KEY (lohko_id);


--
-- Name: nimi_unique; Type: CONSTRAINT; Schema: public; Owner: tfsliiga; Tablespace: 
--

ALTER TABLE ONLY joukkue
    ADD CONSTRAINT nimi_unique UNIQUE (nimi);


--
-- Name: ottelu_pkey; Type: CONSTRAINT; Schema: public; Owner: tfsliiga; Tablespace: 
--

ALTER TABLE ONLY ottelu
    ADD CONSTRAINT ottelu_pkey PRIMARY KEY (ottelu_id);


--
-- Name: reikapeli_pkey; Type: CONSTRAINT; Schema: public; Owner: tfsliiga; Tablespace: 
--

ALTER TABLE ONLY reikapeli
    ADD CONSTRAINT reikapeli_pkey PRIMARY KEY (peli_id);


--
-- Name: sarja_pkey; Type: CONSTRAINT; Schema: public; Owner: tfsliiga; Tablespace: 
--

ALTER TABLE ONLY sarja
    ADD CONSTRAINT sarja_pkey PRIMARY KEY (sarja_id);


--
-- Name: schema_version_pk; Type: CONSTRAINT; Schema: public; Owner: tfsliiga; Tablespace: 
--

ALTER TABLE ONLY schema_version
    ADD CONSTRAINT schema_version_pk PRIMARY KEY (version);


--
-- Name: schema_version_ir_idx; Type: INDEX; Schema: public; Owner: tfsliiga; Tablespace: 
--

CREATE INDEX schema_version_ir_idx ON schema_version USING btree (installed_rank);


--
-- Name: schema_version_s_idx; Type: INDEX; Schema: public; Owner: tfsliiga; Tablespace: 
--

CREATE INDEX schema_version_s_idx ON schema_version USING btree (success);


--
-- Name: schema_version_vr_idx; Type: INDEX; Schema: public; Owner: tfsliiga; Tablespace: 
--

CREATE INDEX schema_version_vr_idx ON schema_version USING btree (version_rank);


--
-- Name: joukkue_yhteyshenkilo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY joukkue
    ADD CONSTRAINT joukkue_yhteyshenkilo_id_fkey FOREIGN KEY (yhteyshenkilo_id) REFERENCES henkilo(henkilo_id) ON DELETE CASCADE;


--
-- Name: lohko_joukkue_lohkojoukkue_joukkue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY lohko_joukkue
    ADD CONSTRAINT lohko_joukkue_lohkojoukkue_joukkue_id_fkey FOREIGN KEY (lohkojoukkue_joukkue_id) REFERENCES joukkue(joukkue_id);


--
-- Name: lohko_joukkue_lohkojoukkue_lohko_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY lohko_joukkue
    ADD CONSTRAINT lohko_joukkue_lohkojoukkue_lohko_id_fkey FOREIGN KEY (lohkojoukkue_lohko_id) REFERENCES lohko(lohko_id);


--
-- Name: lohko_lohkon_sarja_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY lohko
    ADD CONSTRAINT lohko_lohkon_sarja_id_fkey FOREIGN KEY (lohkon_sarja_id) REFERENCES sarja(sarja_id);


--
-- Name: ottelu_kotijoukkue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY ottelu
    ADD CONSTRAINT ottelu_kotijoukkue_id_fkey FOREIGN KEY (kotijoukkue_id) REFERENCES joukkue(joukkue_id);


--
-- Name: ottelu_ottelun_sarja_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY ottelu
    ADD CONSTRAINT ottelu_ottelun_sarja_id_fkey FOREIGN KEY (ottelun_sarja_id) REFERENCES sarja(sarja_id);


--
-- Name: ottelu_vierasjoukkue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY ottelu
    ADD CONSTRAINT ottelu_vierasjoukkue_id_fkey FOREIGN KEY (vierasjoukkue_id) REFERENCES joukkue(joukkue_id);


--
-- Name: reikapeli_pelaaja_koti_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY reikapeli
    ADD CONSTRAINT reikapeli_pelaaja_koti_fkey FOREIGN KEY (pelaaja_koti) REFERENCES henkilo(henkilo_id);


--
-- Name: reikapeli_pelaaja_vieras_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY reikapeli
    ADD CONSTRAINT reikapeli_pelaaja_vieras_fkey FOREIGN KEY (pelaaja_vieras) REFERENCES henkilo(henkilo_id);


--
-- Name: reikapeli_peli_ottelu_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY reikapeli
    ADD CONSTRAINT reikapeli_peli_ottelu_id_fkey FOREIGN KEY (peli_ottelu_id) REFERENCES ottelu(ottelu_id);


--
-- Name: sarja_joukkue_sarjajoukkue_joukkue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY sarja_joukkue
    ADD CONSTRAINT sarja_joukkue_sarjajoukkue_joukkue_id_fkey FOREIGN KEY (sarjajoukkue_joukkue_id) REFERENCES joukkue(joukkue_id);


--
-- Name: sarja_joukkue_sarjajoukkue_sarja_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tfsliiga
--

ALTER TABLE ONLY sarja_joukkue
    ADD CONSTRAINT sarja_joukkue_sarjajoukkue_sarja_id_fkey FOREIGN KEY (sarjajoukkue_sarja_id) REFERENCES sarja(sarja_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

